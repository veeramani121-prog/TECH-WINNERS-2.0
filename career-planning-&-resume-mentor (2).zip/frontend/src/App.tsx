import { createRouter, createRoute, createRootRoute, RouterProvider, Outlet } from '@tanstack/react-router';
import { useInternetIdentity } from './hooks/useInternetIdentity';
import LandingPage from './pages/LandingPage';
import DashboardPage from './pages/DashboardPage';
import ResumeUploadPage from './pages/ResumeUploadPage';
import ResumeReviewPage from './pages/ResumeReviewPage';
import CareerChatPage from './pages/CareerChatPage';
import SkillGapAnalysisPage from './pages/SkillGapAnalysisPage';
import ProfilePage from './pages/ProfilePage';
import Layout from './components/Layout';
import AuthGuard from './components/AuthGuard';
import ProfileSetupModal from './components/ProfileSetupModal';

const rootRoute = createRootRoute({
  component: () => (
    <>
      <ProfileSetupModal />
      <Outlet />
    </>
  ),
});

const landingRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: '/',
  component: LandingPage,
});

const dashboardRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: '/dashboard',
  component: () => (
    <AuthGuard>
      <Layout>
        <DashboardPage />
      </Layout>
    </AuthGuard>
  ),
});

const resumeUploadRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: '/resume/upload',
  component: () => (
    <AuthGuard>
      <Layout>
        <ResumeUploadPage />
      </Layout>
    </AuthGuard>
  ),
});

const resumeReviewRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: '/resume/review',
  component: () => (
    <AuthGuard>
      <Layout>
        <ResumeReviewPage />
      </Layout>
    </AuthGuard>
  ),
});

const careerChatRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: '/chat',
  component: () => (
    <AuthGuard>
      <Layout>
        <CareerChatPage />
      </Layout>
    </AuthGuard>
  ),
});

const skillsRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: '/skills',
  component: () => (
    <AuthGuard>
      <Layout>
        <SkillGapAnalysisPage />
      </Layout>
    </AuthGuard>
  ),
});

const profileRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: '/profile',
  component: () => (
    <AuthGuard>
      <Layout>
        <ProfilePage />
      </Layout>
    </AuthGuard>
  ),
});

const routeTree = rootRoute.addChildren([
  landingRoute,
  dashboardRoute,
  resumeUploadRoute,
  resumeReviewRoute,
  careerChatRoute,
  skillsRoute,
  profileRoute,
]);

const router = createRouter({ routeTree });

declare module '@tanstack/react-router' {
  interface Register {
    router: typeof router;
  }
}

export default function App() {
  return <RouterProvider router={router} />;
}
