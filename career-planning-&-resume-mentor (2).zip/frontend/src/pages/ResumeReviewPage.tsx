import { useGetCallerUserProfile } from '../hooks/useQueries';
import ResumeList from '../components/ResumeList';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { FileCheck, AlertCircle } from 'lucide-react';
import { Alert, AlertDescription } from '@/components/ui/alert';

export default function ResumeReviewPage() {
  const { data: userProfile, isLoading } = useGetCallerUserProfile();

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4"></div>
          <p className="text-muted-foreground">Loading your resumes...</p>
        </div>
      </div>
    );
  }

  const hasResumes = userProfile?.uploadedResumes && userProfile.uploadedResumes.length > 0;

  return (
    <div className="max-w-4xl mx-auto space-y-6 animate-fade-in">
      <div className="space-y-2">
        <h1 className="text-3xl md:text-4xl font-bold">Resume Review</h1>
        <p className="text-muted-foreground text-lg">
          View and analyze your uploaded resumes
        </p>
      </div>

      {!hasResumes ? (
        <Alert>
          <AlertCircle className="h-4 w-4" />
          <AlertDescription>
            You haven't uploaded any resumes yet. Upload your first resume to get started with AI-powered feedback.
          </AlertDescription>
        </Alert>
      ) : (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <FileCheck className="h-5 w-5 text-primary" />
              Your Resumes
            </CardTitle>
            <CardDescription>
              Click on a resume to view detailed analysis and feedback
            </CardDescription>
          </CardHeader>
          <CardContent>
            <ResumeList userProfile={userProfile} />
          </CardContent>
        </Card>
      )}
    </div>
  );
}
