import { useState } from 'react';
import ChatInterface from '../components/ChatInterface';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { MessageSquare } from 'lucide-react';

export default function CareerChatPage() {
  return (
    <div className="max-w-5xl mx-auto space-y-6 animate-fade-in">
      <div className="space-y-2">
        <h1 className="text-3xl md:text-4xl font-bold">Career Chat</h1>
        <p className="text-muted-foreground text-lg">
          Get personalized career guidance and advice from our AI mentor
        </p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <MessageSquare className="h-5 w-5 text-primary" />
            Chat with Your Career Mentor
          </CardTitle>
          <CardDescription>
            Ask questions about career paths, job search strategies, skill development, and more
          </CardDescription>
        </CardHeader>
        <CardContent>
          <ChatInterface />
        </CardContent>
      </Card>
    </div>
  );
}
