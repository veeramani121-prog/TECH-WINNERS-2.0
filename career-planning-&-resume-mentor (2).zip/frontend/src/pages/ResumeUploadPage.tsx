import { useState } from 'react';
import ResumeUploader from '../components/ResumeUploader';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Upload, CheckCircle2 } from 'lucide-react';

export default function ResumeUploadPage() {
  const [uploadSuccess, setUploadSuccess] = useState(false);

  return (
    <div className="max-w-3xl mx-auto space-y-6 animate-fade-in">
      <div className="space-y-2">
        <h1 className="text-3xl md:text-4xl font-bold">Upload Your Resume</h1>
        <p className="text-muted-foreground text-lg">
          Upload your resume in PDF or DOCX format to get started with AI-powered analysis
        </p>
      </div>

      {uploadSuccess ? (
        <Card className="border-success">
          <CardContent className="pt-6">
            <div className="text-center space-y-4">
              <div className="w-16 h-16 rounded-full bg-success/10 flex items-center justify-center mx-auto">
                <CheckCircle2 className="h-8 w-8 text-success" />
              </div>
              <div>
                <h3 className="text-xl font-semibold mb-2">Resume Uploaded Successfully!</h3>
                <p className="text-muted-foreground">
                  Your resume has been saved. You can now view it in the Resume Review section.
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      ) : (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Upload className="h-5 w-5 text-primary" />
              Upload Resume
            </CardTitle>
            <CardDescription>
              Supported formats: PDF, DOCX (Max size: 10MB)
            </CardDescription>
          </CardHeader>
          <CardContent>
            <ResumeUploader onUploadSuccess={() => setUploadSuccess(true)} />
          </CardContent>
        </Card>
      )}

      <Card className="bg-muted/30">
        <CardHeader>
          <CardTitle className="text-lg">What happens next?</CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="flex items-start gap-3">
            <div className="w-6 h-6 rounded-full bg-primary text-primary-foreground flex items-center justify-center text-sm font-bold shrink-0">
              1
            </div>
            <p className="text-sm">Your resume is securely stored and ready for analysis</p>
          </div>
          <div className="flex items-start gap-3">
            <div className="w-6 h-6 rounded-full bg-primary text-primary-foreground flex items-center justify-center text-sm font-bold shrink-0">
              2
            </div>
            <p className="text-sm">Navigate to Resume Review to see detailed feedback</p>
          </div>
          <div className="flex items-start gap-3">
            <div className="w-6 h-6 rounded-full bg-primary text-primary-foreground flex items-center justify-center text-sm font-bold shrink-0">
              3
            </div>
            <p className="text-sm">Use the insights to improve your resume and career prospects</p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
