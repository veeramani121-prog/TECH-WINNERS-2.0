import { useState } from 'react';
import SkillInputForm from '../components/SkillInputForm';
import SkillComparisonChart from '../components/SkillComparisonChart';
import LearningRecommendations from '../components/LearningRecommendations';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Target } from 'lucide-react';

export default function SkillGapAnalysisPage() {
  const [analysisResult, setAnalysisResult] = useState<any>(null);

  return (
    <div className="max-w-5xl mx-auto space-y-6 animate-fade-in">
      <div className="space-y-2">
        <h1 className="text-3xl md:text-4xl font-bold">Skills Gap Analysis</h1>
        <p className="text-muted-foreground text-lg">
          Identify skill gaps and get personalized learning recommendations
        </p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Target className="h-5 w-5 text-primary" />
            Analyze Your Skills
          </CardTitle>
          <CardDescription>
            Enter your current skills and target role to see where you stand
          </CardDescription>
        </CardHeader>
        <CardContent>
          <SkillInputForm onAnalysisComplete={setAnalysisResult} />
        </CardContent>
      </Card>

      {analysisResult && (
        <>
          <SkillComparisonChart data={analysisResult} />
          <LearningRecommendations recommendations={analysisResult.recommendations} />
        </>
      )}
    </div>
  );
}
