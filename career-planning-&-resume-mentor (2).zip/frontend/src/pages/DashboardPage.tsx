import { useGetCallerUserProfile } from '../hooks/useQueries';
import DashboardHeader from '../components/DashboardHeader';
import QuickActions from '../components/QuickActions';
import ProgressCard from '../components/ProgressCard';
import RecentActivity from '../components/RecentActivity';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { FileText, Target, MessageSquare } from 'lucide-react';

export default function DashboardPage() {
  const { data: userProfile, isLoading } = useGetCallerUserProfile();

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4"></div>
          <p className="text-muted-foreground">Loading your dashboard...</p>
        </div>
      </div>
    );
  }

  const resumeCount = userProfile?.uploadedResumes?.length || 0;
  const reviewCount = userProfile?.reviewedResumes?.length || 0;
  const goalsCount = userProfile?.careerGoals?.length || 0;

  return (
    <div className="space-y-8 animate-fade-in">
      <DashboardHeader userName={userProfile?.name || 'User'} />

      <QuickActions />

      <div className="grid md:grid-cols-3 gap-6">
        <ProgressCard
          title="Resumes Uploaded"
          value={resumeCount}
          icon={FileText}
          color="primary"
        />
        <ProgressCard
          title="Reviews Completed"
          value={reviewCount}
          icon={FileText}
          color="success"
        />
        <ProgressCard
          title="Career Goals"
          value={goalsCount}
          icon={Target}
          color="secondary"
        />
      </div>

      <div className="grid md:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <MessageSquare className="h-5 w-5 text-primary" />
              Getting Started
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="flex items-start gap-3">
              <div className="w-6 h-6 rounded-full bg-primary text-primary-foreground flex items-center justify-center text-sm font-bold shrink-0">
                1
              </div>
              <div>
                <p className="font-medium">Upload Your Resume</p>
                <p className="text-sm text-muted-foreground">
                  Start by uploading your current resume for analysis
                </p>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <div className="w-6 h-6 rounded-full bg-primary text-primary-foreground flex items-center justify-center text-sm font-bold shrink-0">
                2
              </div>
              <div>
                <p className="font-medium">Get Feedback</p>
                <p className="text-sm text-muted-foreground">
                  Review detailed feedback and improvement suggestions
                </p>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <div className="w-6 h-6 rounded-full bg-primary text-primary-foreground flex items-center justify-center text-sm font-bold shrink-0">
                3
              </div>
              <div>
                <p className="font-medium">Plan Your Career</p>
                <p className="text-sm text-muted-foreground">
                  Use career chat and skills analysis to plan your next steps
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        <RecentActivity userProfile={userProfile} />
      </div>
    </div>
  );
}
