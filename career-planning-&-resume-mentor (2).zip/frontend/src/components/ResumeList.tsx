import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { FileText, Eye } from 'lucide-react';
import type { UserProfile } from '../backend';
import ResumeFeedback from './ResumeFeedback';

interface ResumeListProps {
  userProfile: UserProfile | null | undefined;
}

export default function ResumeList({ userProfile }: ResumeListProps) {
  const [selectedResumeIndex, setSelectedResumeIndex] = useState<number | null>(null);

  const resumes = userProfile?.uploadedResumes || [];

  if (selectedResumeIndex !== null) {
    return (
      <div className="space-y-4">
        <Button variant="outline" onClick={() => setSelectedResumeIndex(null)}>
          ← Back to Resume List
        </Button>
        <ResumeFeedback resumeIndex={selectedResumeIndex} />
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {resumes.map((resume, index) => (
        <Card key={index} className="hover:shadow-medium transition-shadow">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center">
                  <FileText className="h-6 w-6 text-primary" />
                </div>
                <div>
                  <p className="font-semibold">Resume {index + 1}</p>
                  <p className="text-sm text-muted-foreground">
                    Uploaded {new Date().toLocaleDateString()}
                  </p>
                </div>
              </div>
              <Button onClick={() => setSelectedResumeIndex(index)}>
                <Eye className="h-4 w-4 mr-2" />
                View Analysis
              </Button>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}
