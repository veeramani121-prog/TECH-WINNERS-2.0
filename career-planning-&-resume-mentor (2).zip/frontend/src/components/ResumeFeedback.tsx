import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from '@/components/ui/accordion';
import FeedbackSection from './FeedbackSection';
import { CheckCircle2, AlertTriangle, Lightbulb, FileText } from 'lucide-react';

interface ResumeFeedbackProps {
  resumeIndex: number;
}

export default function ResumeFeedback({ resumeIndex }: ResumeFeedbackProps) {
  // Mock feedback data - in a real app, this would come from backend analysis
  const feedback = {
    structureScore: 85,
    contentScore: 78,
    keywordScore: 72,
    formattingScore: 90,
    strengths: [
      'Clear and concise professional summary',
      'Well-organized work experience section',
      'Quantifiable achievements with metrics',
      'Consistent formatting throughout',
    ],
    weaknesses: [
      'Missing relevant keywords for target role',
      'Education section could be more detailed',
      'Limited technical skills section',
      'No mention of certifications or awards',
    ],
    improvements: [
      'Add industry-specific keywords to improve ATS compatibility',
      'Include more action verbs at the start of bullet points',
      'Expand technical skills section with proficiency levels',
      'Add a projects or portfolio section if applicable',
      'Consider adding relevant certifications',
    ],
  };

  const overallScore = Math.round(
    (feedback.structureScore + feedback.contentScore + feedback.keywordScore + feedback.formattingScore) / 4
  );

  return (
    <div className="space-y-6">
      <Card className="border-2 border-primary/20">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <FileText className="h-5 w-5 text-primary" />
            Resume Analysis - Resume {resumeIndex + 1}
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-6">
            <div className="text-center">
              <div className="inline-flex items-center justify-center w-24 h-24 rounded-full bg-primary/10 mb-4">
                <span className="text-3xl font-bold text-primary">{overallScore}</span>
              </div>
              <p className="text-lg font-semibold">Overall Score</p>
              <p className="text-sm text-muted-foreground">
                Your resume is {overallScore >= 80 ? 'excellent' : overallScore >= 60 ? 'good' : 'needs improvement'}
              </p>
            </div>

            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div className="text-center p-4 rounded-lg bg-muted">
                <p className="text-2xl font-bold text-primary">{feedback.structureScore}</p>
                <p className="text-sm text-muted-foreground">Structure</p>
              </div>
              <div className="text-center p-4 rounded-lg bg-muted">
                <p className="text-2xl font-bold text-primary">{feedback.contentScore}</p>
                <p className="text-sm text-muted-foreground">Content</p>
              </div>
              <div className="text-center p-4 rounded-lg bg-muted">
                <p className="text-2xl font-bold text-primary">{feedback.keywordScore}</p>
                <p className="text-sm text-muted-foreground">Keywords</p>
              </div>
              <div className="text-center p-4 rounded-lg bg-muted">
                <p className="text-2xl font-bold text-primary">{feedback.formattingScore}</p>
                <p className="text-sm text-muted-foreground">Formatting</p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      <Accordion type="single" collapsible className="space-y-4">
        <AccordionItem value="strengths" className="border rounded-lg px-4">
          <AccordionTrigger className="hover:no-underline">
            <div className="flex items-center gap-2">
              <CheckCircle2 className="h-5 w-5 text-success" />
              <span className="font-semibold">Strengths ({feedback.strengths.length})</span>
            </div>
          </AccordionTrigger>
          <AccordionContent>
            <FeedbackSection items={feedback.strengths} variant="positive" />
          </AccordionContent>
        </AccordionItem>

        <AccordionItem value="weaknesses" className="border rounded-lg px-4">
          <AccordionTrigger className="hover:no-underline">
            <div className="flex items-center gap-2">
              <AlertTriangle className="h-5 w-5 text-warning" />
              <span className="font-semibold">Areas to Improve ({feedback.weaknesses.length})</span>
            </div>
          </AccordionTrigger>
          <AccordionContent>
            <FeedbackSection items={feedback.weaknesses} variant="negative" />
          </AccordionContent>
        </AccordionItem>

        <AccordionItem value="improvements" className="border rounded-lg px-4">
          <AccordionTrigger className="hover:no-underline">
            <div className="flex items-center gap-2">
              <Lightbulb className="h-5 w-5 text-secondary" />
              <span className="font-semibold">Actionable Suggestions ({feedback.improvements.length})</span>
            </div>
          </AccordionTrigger>
          <AccordionContent>
            <FeedbackSection items={feedback.improvements} variant="neutral" />
          </AccordionContent>
        </AccordionItem>
      </Accordion>
    </div>
  );
}
