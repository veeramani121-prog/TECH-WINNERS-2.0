import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Clock, FileText, MessageSquare, Target } from 'lucide-react';
import type { LucideIcon } from 'lucide-react';
import type { UserProfile } from '../backend';

interface RecentActivityProps {
  userProfile: UserProfile | null | undefined;
}

interface Activity {
  type: string;
  text: string;
  icon: LucideIcon;
}

export default function RecentActivity({ userProfile }: RecentActivityProps) {
  const activities: Activity[] = [];

  if (userProfile?.uploadedResumes && userProfile.uploadedResumes.length > 0) {
    activities.push({
      type: 'resume',
      text: `Uploaded ${userProfile.uploadedResumes.length} resume${userProfile.uploadedResumes.length > 1 ? 's' : ''}`,
      icon: FileText,
    });
  }

  if (userProfile?.reviewedResumes && userProfile.reviewedResumes.length > 0) {
    activities.push({
      type: 'review',
      text: `Completed ${userProfile.reviewedResumes.length} resume review${userProfile.reviewedResumes.length > 1 ? 's' : ''}`,
      icon: FileText,
    });
  }

  if (userProfile?.careerGoals && userProfile.careerGoals.length > 0) {
    activities.push({
      type: 'goal',
      text: `Set ${userProfile.careerGoals.length} career goal${userProfile.careerGoals.length > 1 ? 's' : ''}`,
      icon: Target,
    });
  }

  if (activities.length === 0) {
    activities.push({
      type: 'welcome',
      text: 'Welcome! Start by uploading your resume',
      icon: MessageSquare,
    });
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Clock className="h-5 w-5 text-primary" />
          Recent Activity
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {activities.map((activity, index) => {
            const Icon = activity.icon;
            return (
              <div key={index} className="flex items-start gap-3">
                <div className="w-8 h-8 rounded-lg bg-muted flex items-center justify-center shrink-0">
                  <Icon className="h-4 w-4 text-muted-foreground" />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm">{activity.text}</p>
                </div>
              </div>
            );
          })}
        </div>
      </CardContent>
    </Card>
  );
}
