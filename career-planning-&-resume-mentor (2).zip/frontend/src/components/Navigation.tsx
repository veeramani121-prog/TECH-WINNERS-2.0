import { useNavigate, useRouterState } from '@tanstack/react-router';
import { useInternetIdentity } from '../hooks/useInternetIdentity';
import LoginButton from './LoginButton';
import { Button } from '@/components/ui/button';
import { Sheet, SheetContent, SheetTrigger } from '@/components/ui/sheet';
import { Menu, Home, Upload, FileCheck, MessageSquare, Target, User } from 'lucide-react';
import { useState } from 'react';

export default function Navigation() {
  const navigate = useNavigate();
  const { identity } = useInternetIdentity();
  const routerState = useRouterState();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const isAuthenticated = !!identity;
  const currentPath = routerState.location.pathname;

  const navItems = isAuthenticated
    ? [
        { label: 'Dashboard', path: '/dashboard', icon: Home },
        { label: 'Upload Resume', path: '/resume/upload', icon: Upload },
        { label: 'Resume Review', path: '/resume/review', icon: FileCheck },
        { label: 'Career Chat', path: '/chat', icon: MessageSquare },
        { label: 'Skills Analysis', path: '/skills', icon: Target },
        { label: 'Profile', path: '/profile', icon: User },
      ]
    : [];

  const handleNavigation = (path: string) => {
    navigate({ to: path });
    setMobileMenuOpen(false);
  };

  return (
    <nav className="border-b bg-card/95 backdrop-blur-sm sticky top-0 z-50">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          <button
            onClick={() => handleNavigation(isAuthenticated ? '/dashboard' : '/')}
            className="text-xl font-bold text-primary hover:text-primary/80 transition-colors"
          >
            Career Mentor
          </button>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center gap-6">
            {navItems.map((item) => {
              const Icon = item.icon;
              return (
                <button
                  key={item.path}
                  onClick={() => handleNavigation(item.path)}
                  className={`flex items-center gap-2 text-sm font-medium transition-colors hover:text-primary ${
                    currentPath === item.path ? 'text-primary' : 'text-muted-foreground'
                  }`}
                >
                  <Icon className="h-4 w-4" />
                  {item.label}
                </button>
              );
            })}
            <LoginButton />
          </div>

          {/* Mobile Navigation */}
          <div className="md:hidden flex items-center gap-2">
            <LoginButton />
            {isAuthenticated && (
              <Sheet open={mobileMenuOpen} onOpenChange={setMobileMenuOpen}>
                <SheetTrigger asChild>
                  <Button variant="ghost" size="icon">
                    <Menu className="h-5 w-5" />
                  </Button>
                </SheetTrigger>
                <SheetContent side="right">
                  <div className="flex flex-col gap-4 mt-8">
                    {navItems.map((item) => {
                      const Icon = item.icon;
                      return (
                        <button
                          key={item.path}
                          onClick={() => handleNavigation(item.path)}
                          className={`flex items-center gap-3 text-base font-medium transition-colors hover:text-primary p-2 rounded-md ${
                            currentPath === item.path
                              ? 'text-primary bg-accent'
                              : 'text-muted-foreground'
                          }`}
                        >
                          <Icon className="h-5 w-5" />
                          {item.label}
                        </button>
                      );
                    })}
                  </div>
                </SheetContent>
              </Sheet>
            )}
          </div>
        </div>
      </div>
    </nav>
  );
}
