import { useNavigate } from '@tanstack/react-router';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Upload, MessageSquare, Target, ArrowRight } from 'lucide-react';

export default function QuickActions() {
  const navigate = useNavigate();

  const actions = [
    {
      title: 'Upload Resume',
      description: 'Upload a new resume for analysis',
      icon: Upload,
      path: '/resume/upload',
      color: 'primary',
    },
    {
      title: 'Career Chat',
      description: 'Get personalized career guidance',
      icon: MessageSquare,
      path: '/chat',
      color: 'secondary',
    },
    {
      title: 'Analyze Skills',
      description: 'Identify skill gaps and learning paths',
      icon: Target,
      path: '/skills',
      color: 'success',
    },
  ];

  return (
    <Card>
      <CardHeader>
        <CardTitle>Quick Actions</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid md:grid-cols-3 gap-4">
          {actions.map((action) => {
            const Icon = action.icon;
            return (
              <Button
                key={action.path}
                variant="outline"
                className="h-auto p-6 flex flex-col items-start gap-3 hover:border-primary hover:bg-primary/5 transition-all"
                onClick={() => navigate({ to: action.path })}
              >
                <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center">
                  <Icon className="h-6 w-6 text-primary" />
                </div>
                <div className="text-left space-y-1">
                  <p className="font-semibold text-base">{action.title}</p>
                  <p className="text-sm text-muted-foreground">{action.description}</p>
                </div>
                <ArrowRight className="h-4 w-4 ml-auto text-muted-foreground" />
              </Button>
            );
          })}
        </div>
      </CardContent>
    </Card>
  );
}
