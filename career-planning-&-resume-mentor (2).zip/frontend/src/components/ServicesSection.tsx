import { Card, CardHeader, CardTitle, CardDescription, CardContent } from '@/components/ui/card';
import { FileText, Target, TrendingUp } from 'lucide-react';

export default function ServicesSection() {
  const services = [
    {
      icon: '/assets/generated/resume-icon.dim_200x200.png',
      title: 'Resume Review & Optimization',
      description: 'Get detailed feedback on your resume structure, content, keywords, and formatting. Receive actionable suggestions to make your resume stand out to recruiters.',
      iconComponent: FileText,
    },
    {
      icon: '/assets/generated/career-icon.dim_200x200.png',
      title: 'Career Planning Guidance',
      description: 'Chat with our AI mentor to explore career paths, discuss job market trends, and get personalized advice for your professional development journey.',
      iconComponent: TrendingUp,
    },
    {
      icon: '/assets/generated/skills-icon.dim_200x200.png',
      title: 'Skills Gap Analysis',
      description: 'Identify the skills you need for your target role. Get customized learning paths and resource recommendations to bridge the gap and achieve your goals.',
      iconComponent: Target,
    },
  ];

  return (
    <section className="py-20 bg-muted/30">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16 space-y-4">
          <h2 className="text-4xl md:text-5xl font-bold">Our Services</h2>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Comprehensive career development tools to help you succeed
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8 max-w-6xl mx-auto">
          {services.map((service, index) => {
            const IconComponent = service.iconComponent;
            return (
              <Card
                key={index}
                className="border-2 hover:border-primary/50 transition-all duration-300 hover:shadow-medium"
              >
                <CardHeader className="text-center">
                  <div className="mx-auto mb-4 relative">
                    <div className="w-24 h-24 mx-auto rounded-2xl bg-primary/10 flex items-center justify-center">
                      <img
                        src={service.icon}
                        alt={service.title}
                        className="w-16 h-16 object-contain"
                      />
                    </div>
                    <div className="absolute -bottom-2 -right-2 w-10 h-10 rounded-full bg-secondary flex items-center justify-center">
                      <IconComponent className="h-5 w-5 text-secondary-foreground" />
                    </div>
                  </div>
                  <CardTitle className="text-2xl">{service.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <CardDescription className="text-base leading-relaxed">
                    {service.description}
                  </CardDescription>
                </CardContent>
              </Card>
            );
          })}
        </div>
      </div>
    </section>
  );
}
