import { Card, CardContent } from '@/components/ui/card';
import { Quote } from 'lucide-react';

export default function TestimonialsSection() {
  const testimonials = [
    {
      text: "The resume feedback was incredibly detailed and actionable. I updated my resume based on the suggestions and landed three interviews within two weeks!",
      author: "Sarah Chen",
      role: "Software Engineer",
    },
    {
      text: "The career chat feature helped me navigate a difficult career transition. The guidance was personalized and practical, exactly what I needed.",
      author: "Michael Rodriguez",
      role: "Product Manager",
    },
    {
      text: "The skills gap analysis showed me exactly what I needed to learn for my dream job. The learning path recommendations were spot-on and helped me upskill efficiently.",
      author: "Emily Thompson",
      role: "Data Analyst",
    },
  ];

  return (
    <section className="py-20">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16 space-y-4">
          <h2 className="text-4xl md:text-5xl font-bold">Success Stories</h2>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            See how Career Mentor has helped professionals achieve their goals
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8 max-w-6xl mx-auto">
          {testimonials.map((testimonial, index) => (
            <Card key={index} className="border-2 hover:shadow-medium transition-shadow">
              <CardContent className="pt-6">
                <Quote className="h-8 w-8 text-primary/30 mb-4" />
                <p className="text-base leading-relaxed mb-6 italic">
                  "{testimonial.text}"
                </p>
                <div className="border-t pt-4">
                  <p className="font-semibold">{testimonial.author}</p>
                  <p className="text-sm text-muted-foreground">{testimonial.role}</p>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
}
