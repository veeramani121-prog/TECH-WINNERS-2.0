import { CheckCircle2, AlertCircle, Lightbulb } from 'lucide-react';

interface FeedbackSectionProps {
  items: string[];
  variant: 'positive' | 'negative' | 'neutral';
}

export default function FeedbackSection({ items, variant }: FeedbackSectionProps) {
  const config = {
    positive: {
      icon: CheckCircle2,
      iconColor: 'text-success',
      bgColor: 'bg-success/10',
    },
    negative: {
      icon: AlertCircle,
      iconColor: 'text-warning',
      bgColor: 'bg-warning/10',
    },
    neutral: {
      icon: Lightbulb,
      iconColor: 'text-secondary',
      bgColor: 'bg-secondary/10',
    },
  };

  const { icon: Icon, iconColor, bgColor } = config[variant];

  return (
    <div className="space-y-3 pt-4">
      {items.map((item, index) => (
        <div key={index} className="flex items-start gap-3">
          <div className={`w-8 h-8 rounded-lg ${bgColor} flex items-center justify-center shrink-0`}>
            <Icon className={`h-4 w-4 ${iconColor}`} />
          </div>
          <p className="text-sm leading-relaxed pt-1">{item}</p>
        </div>
      ))}
    </div>
  );
}
