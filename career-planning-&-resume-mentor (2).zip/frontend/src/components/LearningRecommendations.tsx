import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { BookOpen, ExternalLink } from 'lucide-react';

interface Recommendation {
  skill: string;
  priority: string;
  resources: string[];
}

interface LearningRecommendationsProps {
  recommendations: Recommendation[];
}

export default function LearningRecommendations({ recommendations }: LearningRecommendationsProps) {
  const priorityColors = {
    High: 'destructive',
    Medium: 'secondary',
    Low: 'outline',
  } as const;

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <BookOpen className="h-5 w-5 text-primary" />
          Learning Recommendations
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-6">
          {recommendations.map((rec, index) => (
            <div key={index} className="border rounded-lg p-4 space-y-3">
              <div className="flex items-center justify-between">
                <h4 className="font-semibold text-lg">{rec.skill}</h4>
                <Badge variant={priorityColors[rec.priority as keyof typeof priorityColors]}>
                  {rec.priority} Priority
                </Badge>
              </div>
              <div className="space-y-2">
                <p className="text-sm font-medium text-muted-foreground">Recommended Resources:</p>
                <ul className="space-y-2">
                  {rec.resources.map((resource, idx) => (
                    <li key={idx} className="flex items-center gap-2 text-sm">
                      <ExternalLink className="h-4 w-4 text-primary shrink-0" />
                      <span>{resource}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}
