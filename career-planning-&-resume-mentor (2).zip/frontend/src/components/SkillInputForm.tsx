import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { X, Plus } from 'lucide-react';

interface SkillInputFormProps {
  onAnalysisComplete: (result: any) => void;
}

export default function SkillInputForm({ onAnalysisComplete }: SkillInputFormProps) {
  const [currentSkills, setCurrentSkills] = useState<string[]>([]);
  const [skillInput, setSkillInput] = useState('');
  const [targetRole, setTargetRole] = useState('');
  const [isAnalyzing, setIsAnalyzing] = useState(false);

  const addSkill = () => {
    if (skillInput.trim() && !currentSkills.includes(skillInput.trim())) {
      setCurrentSkills([...currentSkills, skillInput.trim()]);
      setSkillInput('');
    }
  };

  const removeSkill = (skill: string) => {
    setCurrentSkills(currentSkills.filter((s) => s !== skill));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (currentSkills.length === 0 || !targetRole.trim()) return;

    setIsAnalyzing(true);

    // Simulate analysis - in a real app, this would call the backend
    setTimeout(() => {
      const mockResult = {
        currentSkills,
        targetRole,
        requiredSkills: [
          'JavaScript',
          'React',
          'TypeScript',
          'Node.js',
          'Git',
          'REST APIs',
          'Testing',
          'Agile',
        ],
        matchRate: 65,
        recommendations: [
          {
            skill: 'TypeScript',
            priority: 'High',
            resources: ['TypeScript Official Documentation', 'TypeScript Deep Dive (Book)', 'Execute Program'],
          },
          {
            skill: 'Testing',
            priority: 'High',
            resources: ['Jest Documentation', 'Testing Library', 'Test Automation University'],
          },
          {
            skill: 'Node.js',
            priority: 'Medium',
            resources: ['Node.js Official Docs', 'Node.js Design Patterns', 'FreeCodeCamp Node Course'],
          },
          {
            skill: 'Agile Methodologies',
            priority: 'Medium',
            resources: ['Scrum Guide', 'Agile Manifesto', 'Mountain Goat Software Blog'],
          },
        ],
      };

      onAnalysisComplete(mockResult);
      setIsAnalyzing(false);
    }, 1500);
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div className="space-y-2">
        <Label htmlFor="targetRole">Target Job Role</Label>
        <Input
          id="targetRole"
          value={targetRole}
          onChange={(e) => setTargetRole(e.target.value)}
          placeholder="e.g., Senior Frontend Developer"
          required
        />
      </div>

      <div className="space-y-2">
        <Label htmlFor="skills">Your Current Skills</Label>
        <div className="flex gap-2">
          <Input
            id="skills"
            value={skillInput}
            onChange={(e) => setSkillInput(e.target.value)}
            onKeyPress={(e) => {
              if (e.key === 'Enter') {
                e.preventDefault();
                addSkill();
              }
            }}
            placeholder="Enter a skill and press Enter"
          />
          <Button type="button" onClick={addSkill} variant="outline" size="icon">
            <Plus className="h-4 w-4" />
          </Button>
        </div>
        {currentSkills.length > 0 && (
          <div className="flex flex-wrap gap-2 mt-3">
            {currentSkills.map((skill) => (
              <Badge key={skill} variant="secondary" className="px-3 py-1">
                {skill}
                <button
                  type="button"
                  onClick={() => removeSkill(skill)}
                  className="ml-2 hover:text-destructive"
                >
                  <X className="h-3 w-3" />
                </button>
              </Badge>
            ))}
          </div>
        )}
      </div>

      <Button type="submit" disabled={isAnalyzing || currentSkills.length === 0 || !targetRole.trim()} className="w-full">
        {isAnalyzing ? 'Analyzing...' : 'Analyze Skills Gap'}
      </Button>
    </form>
  );
}
