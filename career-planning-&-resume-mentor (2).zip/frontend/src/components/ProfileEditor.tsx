import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { useSaveCallerUserProfile } from '../hooks/useQueries';
import type { UserProfile } from '../backend';
import { Save, X } from 'lucide-react';

interface ProfileEditorProps {
  userProfile: UserProfile | null | undefined;
  onCancel: () => void;
  onSave: () => void;
}

export default function ProfileEditor({ userProfile, onCancel, onSave }: ProfileEditorProps) {
  const [name, setName] = useState(userProfile?.name || '');
  const saveProfile = useSaveCallerUserProfile();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;

    try {
      await saveProfile.mutateAsync({
        name: name.trim(),
        careerGoals: userProfile?.careerGoals || [],
        uploadedResumes: userProfile?.uploadedResumes || [],
        reviewedResumes: userProfile?.reviewedResumes || [],
      });
      onSave();
    } catch (error) {
      console.error('Failed to save profile:', error);
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>Edit Profile</CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="space-y-2">
            <Label htmlFor="name">Name</Label>
            <Input
              id="name"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="Enter your full name"
              required
            />
          </div>

          <div className="flex gap-3">
            <Button type="submit" disabled={saveProfile.isPending || !name.trim()} className="flex-1">
              <Save className="h-4 w-4 mr-2" />
              {saveProfile.isPending ? 'Saving...' : 'Save Changes'}
            </Button>
            <Button type="button" variant="outline" onClick={onCancel} disabled={saveProfile.isPending}>
              <X className="h-4 w-4 mr-2" />
              Cancel
            </Button>
          </div>
        </form>
      </CardContent>
    </Card>
  );
}
