import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { CheckCircle2, Circle } from 'lucide-react';

interface SkillComparisonChartProps {
  data: {
    currentSkills: string[];
    requiredSkills: string[];
    matchRate: number;
  };
}

export default function SkillComparisonChart({ data }: SkillComparisonChartProps) {
  const { currentSkills, requiredSkills, matchRate } = data;

  const skillsComparison = requiredSkills.map((skill) => ({
    skill,
    hasSkill: currentSkills.some((s) => s.toLowerCase() === skill.toLowerCase()),
  }));

  return (
    <Card>
      <CardHeader>
        <CardTitle>Skills Comparison</CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="text-center">
          <div className="inline-flex items-center justify-center w-24 h-24 rounded-full bg-primary/10 mb-4">
            <span className="text-3xl font-bold text-primary">{matchRate}%</span>
          </div>
          <p className="text-lg font-semibold">Skill Match Rate</p>
          <p className="text-sm text-muted-foreground">
            You have {currentSkills.length} of {requiredSkills.length} required skills
          </p>
        </div>

        <div className="space-y-3">
          <h4 className="font-semibold">Required Skills for Target Role</h4>
          <div className="grid gap-3">
            {skillsComparison.map(({ skill, hasSkill }) => (
              <div key={skill} className="flex items-center justify-between p-3 rounded-lg bg-muted">
                <div className="flex items-center gap-3">
                  {hasSkill ? (
                    <CheckCircle2 className="h-5 w-5 text-success" />
                  ) : (
                    <Circle className="h-5 w-5 text-muted-foreground" />
                  )}
                  <span className={hasSkill ? 'font-medium' : 'text-muted-foreground'}>{skill}</span>
                </div>
                {hasSkill && (
                  <span className="text-xs px-2 py-1 rounded-full bg-success/10 text-success font-medium">
                    You have this
                  </span>
                )}
              </div>
            ))}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
